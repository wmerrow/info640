library(tidyverse)
library(dplyr)

opp <- read.csv(file = "data/tract_outcomes_simple.csv", header=TRUE)
str(opp)
glimpse(opp)

# mean, median, min, max
# "digits = 5" avoids default rounding on max
summary(opp$kfr_pooled_pooled_p25, digits = 10)
summary(opp$jail_pooled_pooled_p25, digits = 10)

# range
max(opp$kfr_pooled_pooled_p25, na.rm = TRUE) - min(opp$kfr_pooled_pooled_p25, na.rm = TRUE)
max(opp$jail_pooled_pooled_p25, na.rm = TRUE) - min(opp$jail_pooled_pooled_p25, na.rm = TRUE)

# standard deviation
sd(opp$kfr_pooled_pooled_p25, na.rm = TRUE)
sd(opp$jail_pooled_pooled_p25, na.rm = TRUE)

# histograms
hist(opp$kfr_pooled_pooled_p25, breaks = 75, main = "Distribution of Income Ranks", xlab = "Household income rank")
hist(opp$jail_pooled_pooled_p25, breaks = 75, main = "Distribution of Incarceration Rates", xlab = "Incarceration rate")


# look at missing data

# income
opp_kfr_na <- opp[is.na(opp$kfr_pooled_pooled_p25),]
str(opp_kfr_na)
sum(is.na(opp_kfr_na$kfr_pooled_pooled_p25))
sum(is.na(opp_kfr_na$jail_pooled_pooled_p25)) # all income NAs also have NA incarceration
sum(is.na(opp_kfr_na$pooled_pooled_count)) # all income NAs also have NA count
# incarceration
opp_jail_na <- opp[is.na(opp$jail_pooled_pooled_p25),]
str(opp_jail_na)
sum(is.na(opp_jail_na$jail_pooled_pooled_p25))
sum(is.na(opp_jail_na$kfr_pooled_pooled_p25)) # some tracts have NA incarceration but do have data for income
sum(is.na(opp_jail_na$pooled_pooled_count)) # some tracts have NA incarceration but do have data for count


# look at outliers

# create dataframe with variables of interest for easier sorting/viewing outliers
opp_sort <- opp[,c(1:5,6,8)]
str(opp_sort)

# sort by income rank to view income head and tail, with income NAs removed
opp_kfr_sort <- opp_sort %>% arrange(desc(kfr_pooled_pooled_p25))
opp_kfr_sort <- opp_kfr_sort[!is.na(opp_kfr_sort$kfr_pooled_pooled_p25),]
head(opp_kfr_sort, 20) # only two income values over 1
tail(opp_kfr_sort, 20) # only one income value below 0

# sort by incarceration rate to view incarceration head and tail, with incarceration NAs removed
opp_jail_sort <- opp_sort %>% arrange(desc(jail_pooled_pooled_p25))
opp_jail_sort <- opp_jail_sort[!is.na(opp_jail_sort$jail_pooled_pooled_p25),]
head(opp_jail_sort, 20) # only two incarceration values over .5
tail(opp_jail_sort, 20)
tail(opp_jail_sort, 100) # many incarceration below zero

