library(tidyverse)
library(dplyr)
library(ggplot2)

vote <- read.csv(file = "data/averages.csv", header=TRUE, stringsAsFactors = FALSE)
str(vote)
glimpse(vote)


# look at which Congresses (years) are included, and counts by year

unique(vote$congress)
length(vote$congress[vote$congress == 116])
length(vote$congress[vote$congress == 115])
length(vote$congress[vote$congress == 0])


# create dataframes filtered to particular chambers/congresses

h116 <- filter(vote, vote$congress == 116, vote$chamber == "house")
h115 <- filter(vote, vote$congress == 115, vote$chamber == "house")
h0 <- filter(vote, vote$congress == 0, vote$chamber == "house")

s116 <- filter(vote, vote$congress == 116, vote$chamber == "senate")
s115 <- filter(vote, vote$congress == 115, vote$chamber == "senate")
s0 <- filter(vote, vote$congress == 0, vote$chamber == "senate")


# look at distributions of net_trump_vote

hist(vote$net_trump_vote, 
     main = "All", 
     xlab = "Net Trump Vote", 
     breaks = 50, 
     col = "gray", 
     xlim = c(-100, 100))

hist(h115$net_trump_vote, 
     main = "House - 115th", 
     xlab = "Net Trump Vote", 
     breaks = 50, 
     col = "gray", 
     xlim = c(-100, 100),
     ylim = c(0, 50))

hist(h116$net_trump_vote, 
     main = "House - 116th", 
     xlab = "Net Trump Vote", 
     breaks = 50, 
     col = "gray", 
     xlim = c(-100, 100),
     ylim = c(0, 50))

hist(s115$net_trump_vote, 
     main = "Senate - 115th", 
     xlab = "Net Trump Vote", 
     breaks = 25, 
     col = "gray", 
     xlim = c(-100, 100),
     ylim = c(0, 20))

hist(s116$net_trump_vote, 
     main = "Senate - 116th", 
     xlab = "Net Trump Vote", 
     breaks = 25, 
     col = "gray", 
     xlim = c(-100, 100),
     ylim = c(0, 20))


# look at distributions of agree_pct

hist(vote$agree_pct, 
     main = "All", 
     xlab = "Agreement with Trump", 
     breaks = 50, 
     col = "gray", 
     xlim = c(0, 1))

hist(h115$agree_pct, 
     main = "House - 115th", 
     xlab = "Agreement with Trump", 
     breaks = 50, 
     col = "gray", 
     xlim = c(0, 1),
     ylim = c(0, 130))

hist(h116$agree_pct, 
     main = "House - 116th", 
     xlab = "Agreement with Trump", 
     breaks = 50, 
     col = "gray", 
     xlim = c(0, 1),
     ylim = c(0, 130))

hist(s115$agree_pct, 
     main = "Senate - 115th", 
     xlab = "Agreement with Trump", 
     breaks = 50, 
     col = "gray", 
     xlim = c(0, 1),
     ylim = c(0, 25))

hist(s116$agree_pct, 
     main = "Senate - 116th", 
     xlab = "Agreement with Trump", 
     breaks = 50, 
     col = "gray", 
     xlim = c(0, 1),
     ylim = c(0, 25))


# look at vote data to see why there is a difference between 115th and 116th

bills <- read.csv(file = "data/vote_predictions.csv", header=TRUE, stringsAsFactors = FALSE)
glimpse(bills)
unique(bills$trump_position)

bills$trump_position_num[bills$trump_position == "support"] <- 1
bills$trump_position_num[bills$trump_position == "oppose"] <- 0
unique(bills$trump_position_num)
hist(bills$trump_position_num) 
unique(bills$congress)

bills116 <- filter(bills, bills$congress == 116)
bills115 <- filter(bills, bills$congress == 115)
hist(bills116$trump_position_num) # Trump has opposed nearly all bills in the 116th
hist(bills115$trump_position_num) # Trump supported nearly all bills in the 115th


# scatterplots

ggplot(data = h116, 
  aes(x = net_trump_vote, 
      y = agree_pct, 
      color = party, 
      alpha = 0.5)) +
  geom_point() + 
  ggtitle("House - 116th") +
  xlab("Net Trump Vote in District") +
  ylab("Agreement with Trump") +
  xlim(-100, 100) +
  ylim(0, 1) +
  scale_color_manual(values=c("blue", "purple", "red")) +
  theme_minimal() +
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5))

ggplot(data = h115, 
       aes(x = net_trump_vote, 
           y = agree_pct, 
           color = party, 
           alpha = 0.5)) +
  geom_point() + 
  ggtitle("House - 115th") +
  xlab("Net Trump Vote in District") +
  ylab("Agreement with Trump") +
  xlim(-100, 100) +
  ylim(0, 1) +
  scale_color_manual(values=c("blue", "red")) +
  theme_minimal() +
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5))

ggplot(data = s116, 
       aes(x = net_trump_vote, 
           y = agree_pct, 
           color = party, 
           alpha = 0.5)) +
  geom_point() + 
  ggtitle("Senate - 116th") +
  xlab("Net Trump Vote in State") +
  ylab("Agreement with Trump") +
  xlim(-100, 100) +
  ylim(0, 1) +
  scale_color_manual(values=c("blue", "purple", "red")) +
  theme_minimal() +
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5))

ggplot(data = s115, 
       aes(x = net_trump_vote, 
           y = agree_pct, 
           color = party, 
           alpha = 0.5)) +
  geom_point() + 
  ggtitle("Senate - 115th") +
  xlab("Net Trump Vote in State") +
  ylab("Agreement with Trump") +
  xlim(-100, 100) +
  ylim(0, 1) +
  scale_color_manual(values=c("blue", "purple", "red")) +
  theme_minimal() +
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5))


# correlations

lm_h116 <- lm(agree_pct ~ net_trump_vote, data=h116)
lm_h116
summary(lm_h116)

lm_h115 <- lm(agree_pct ~ net_trump_vote, data=h115)
lm_h115
summary(lm_h115)

lm_s116 <- lm(agree_pct ~ net_trump_vote, data=s116)
lm_s116
summary(lm_s116)

lm_s115 <- lm(agree_pct ~ net_trump_vote, data=s115)
lm_s115
summary(lm_s115)


# scatterplots with regression lines

ggplot(data = h115, 
       aes(x = net_trump_vote, 
           y = agree_pct, 
           color = party, 
           alpha = 0.5)) +
  geom_point() + 
  geom_smooth(method = "lm") +
  ggtitle("House - 115th") +
  xlab("Net Trump Vote in District") +
  ylab("Agreement with Trump") +
  xlim(-100, 100) +
  ylim(0, 1) +
  scale_color_manual(values=c("blue", "red")) +
  theme_minimal() +
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5))

ggplot(data = s115, 
       aes(x = net_trump_vote, 
           y = agree_pct, 
           color = party, 
           alpha = 0.5)) +
  geom_point() + 
  geom_smooth(method = "lm") +
  ggtitle("Senate - 115th") +
  xlab("Net Trump Vote in State") +
  ylab("Agreement with Trump") +
  xlim(-100, 100) +
  ylim(0, 1) +
  scale_color_manual(values=c("blue", "purple", "red")) +
  theme_minimal() +
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5))


# filter to just Democrats and Republicans

h115D <- filter(h115, h115$party == "D")
h115R <- filter(h115, h115$party == "R")
s115D <- filter(s115, s115$party == "D")
s115R <- filter(s115, s115$party == "R")


# correlations for Democrats and Republicans in the 115th Congress

lm_h115D <- lm(agree_pct ~ net_trump_vote, data=h115D)
lm_h115D
summary(lm_h115D)

lm_h115R <- lm(agree_pct ~ net_trump_vote, data=h115R)
lm_h115R
summary(lm_h115R)

lm_s115D <- lm(agree_pct ~ net_trump_vote, data=s115D)
lm_s115D
summary(lm_s115D)

lm_s115R <- lm(agree_pct ~ net_trump_vote, data=s115R)
lm_s115R
summary(lm_s115R)


